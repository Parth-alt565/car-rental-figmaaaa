import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';

export type UserRole = 'user' | 'admin' | null;

interface User {
  email: string;
  role: UserRole;
  name: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, role: 'user' | 'admin') => boolean;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock credentials
const mockCredentials = {
  user: { email: 'user@carental.com', password: 'user123' },
  admin: { email: 'admin@carental.com', password: 'admin123' },
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    // Check localStorage for existing session
    const storedUser = localStorage.getItem('carRentalUser');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const login = (email: string, password: string, role: 'user' | 'admin'): boolean => {
    const credentials = mockCredentials[role];
    
    if (email === credentials.email && password === credentials.password) {
      const newUser: User = {
        email,
        role,
        name: role === 'admin' ? 'Admin User' : 'Guest User',
      };
      setUser(newUser);
      localStorage.setItem('carRentalUser', JSON.stringify(newUser));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('carRentalUser');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};
