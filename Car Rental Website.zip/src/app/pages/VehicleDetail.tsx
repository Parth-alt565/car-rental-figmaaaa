import { useParams, useNavigate } from 'react-router';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { getCarById } from '../data/cars';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Card, CardContent } from '../components/ui/card';
import { ArrowLeft, Users, Settings, Fuel, Calendar, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function VehicleDetail() {
  const { id } = useParams<{ id: string }>();
  const { t } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();

  const car = id ? getCarById(id) : null;

  if (!car) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl mb-4">Vehicle not found</h2>
        <Button onClick={() => navigate('/vehicles')}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Vehicles
        </Button>
      </div>
    );
  }

  const handleBooking = () => {
    if (!user) {
      toast.error('Please login to book a vehicle');
      navigate('/login/user');
      return;
    }
    navigate(`/booking/${car.id}`);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Button variant="ghost" onClick={() => navigate('/vehicles')} className="mb-6">
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Vehicles
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Image Section */}
        <div>
          <div className="aspect-video overflow-hidden rounded-lg bg-gray-100 mb-4">
            <img
              src={car.image}
              alt={car.name}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Details Section */}
        <div>
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="text-4xl mb-2">{car.name}</h1>
              <p className="text-xl text-gray-600">{car.brand} • {car.year}</p>
            </div>
            <Badge
              variant={car.available ? 'default' : 'secondary'}
              className="text-lg px-4 py-2"
            >
              {car.available ? (
                <CheckCircle className="w-5 h-5 mr-2" />
              ) : (
                <XCircle className="w-5 h-5 mr-2" />
              )}
              {car.available ? t('available') : t('notAvailable')}
            </Badge>
          </div>

          <div className="mb-8">
            <div className="flex items-end mb-6">
              <span className="text-5xl">${car.price}</span>
              <span className="text-xl text-gray-600 ml-2">/{t('perDay')}</span>
            </div>

            <Button
              size="lg"
              className="w-full text-lg"
              onClick={handleBooking}
              disabled={!car.available}
            >
              {t('bookNow')}
            </Button>
          </div>

          <Card>
            <CardContent className="p-6">
              <h2 className="text-2xl mb-4">{t('specifications')}</h2>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <Users className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">{t('seats')}</p>
                    <p className="text-lg">{car.seats} Passengers</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <Settings className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">{t('transmission')}</p>
                    <p className="text-lg">{car.transmission}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <Fuel className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">{t('fuelType')}</p>
                    <p className="text-lg">{car.fuelType}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Year</p>
                    <p className="text-lg">{car.year}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}