import { useNavigate } from 'react-router';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { Car, Shield, Clock, Zap, MapPin, Award } from 'lucide-react';

export default function Home() {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const categories = [
    { key: 'suv', icon: Car },
    { key: 'offroad', icon: Car },
    { key: 'sedan', icon: Car },
    { key: 'sports', icon: Zap },
    { key: 'hatchback', icon: Car },
    { key: 'ev', icon: Zap },
  ];

  const features = [
    { icon: Shield, title: 'Verified Vehicles', description: 'All our cars are thoroughly inspected' },
    { icon: Clock, title: '24/7 Support', description: 'Round the clock customer assistance' },
    { icon: MapPin, title: 'Multiple Locations', description: 'Pick up from convenient locations' },
    { icon: Award, title: 'Best Prices', description: 'Competitive rates guaranteed' },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-red-950/30 via-black to-red-900/20"></div>
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwwLDAsMC4wNSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-40"></div>
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-red-600/10 rounded-full blur-[100px]"></div>
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-red-500/10 rounded-full blur-[100px]"></div>
        </div>
        
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="inline-block mb-6 px-6 py-2 rounded-full border border-red-500/30 bg-red-500/10 backdrop-blur-sm">
            <span className="text-red-500 font-semibold tracking-wider text-sm uppercase">Premium Car Rental</span>
          </div>
          
          <h1 className="text-6xl md:text-8xl mb-8 font-bold tracking-tight">
            <span className="block bg-gradient-to-r from-white via-red-100 to-white bg-clip-text text-transparent">
              {t('welcomeTitle')}
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl mb-12 max-w-3xl mx-auto text-gray-300 leading-relaxed">
            {t('welcomeSubtitle')}
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              onClick={() => navigate('/vehicles')}
              className="min-w-[200px] group relative"
            >
              <span className="relative z-10">{t('browseVehicles')}</span>
              <div className="absolute inset-0 bg-gradient-to-r from-red-600 via-red-500 to-red-600 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg"></div>
            </Button>
            
            <Button
              size="lg"
              variant="outline"
              onClick={() => navigate('/vehicles')}
              className="min-w-[200px]"
            >
              Learn More
            </Button>
          </div>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent"></div>
      </section>

      {/* Categories Section */}
      <section className="py-24 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Our Vehicle Categories
              </span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Choose from our premium collection of vehicles
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {categories.map((category) => (
              <Card
                key={category.key}
                className="cursor-pointer group hover:scale-105 transition-all duration-300"
                onClick={() => navigate(`/vehicles?category=${category.key}`)}
              >
                <CardContent className="p-8 text-center">
                  <div className="relative mb-4">
                    <div className="absolute inset-0 bg-red-500 rounded-full blur-xl opacity-0 group-hover:opacity-30 transition-opacity"></div>
                    <category.icon className="w-12 h-12 mx-auto text-red-500 relative z-10 group-hover:scale-110 transition-transform" />
                  </div>
                  <h3 className="font-semibold text-lg group-hover:text-red-500 transition-colors">{t(category.key)}</h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-red-950/10 to-transparent"></div>
        
        <div className="container mx-auto px-4 relative">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Why Choose Us
              </span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Experience luxury and convenience with every rental
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div 
                key={index} 
                className="text-center group relative"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                
                <div className="relative p-8 rounded-2xl border border-white/5 group-hover:border-red-500/30 transition-all backdrop-blur-sm">
                  <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-red-600/20 to-red-500/5 mb-6 group-hover:from-red-600 group-hover:to-red-500 transition-all shadow-lg group-hover:shadow-red-500/50">
                    <feature.icon className="w-10 h-10 text-red-500 group-hover:text-white transition-colors" />
                  </div>
                  <h3 className="text-xl mb-2 font-semibold">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}