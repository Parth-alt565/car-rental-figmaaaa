import { useState, useMemo } from 'react';
import { useSearchParams, useNavigate } from 'react-router';
import { useLanguage } from '../contexts/LanguageContext';
import { cars } from '../data/cars';
import { Card, CardContent, CardFooter } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Users, Settings, Fuel, CheckCircle, XCircle } from 'lucide-react';

export default function Vehicles() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryParam = searchParams.get('category') || 'all';

  const categories = ['all', 'suv', 'offroad', 'sedan', 'sports', 'hatchback', 'ev'];

  const filteredCars = useMemo(() => {
    if (categoryParam === 'all') return cars;
    return cars.filter((car) => car.category === categoryParam);
  }, [categoryParam]);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl mb-8">{t('vehicles')}</h1>

      {/* Category Tabs */}
      <Tabs value={categoryParam} className="mb-8">
        <TabsList className="flex flex-wrap h-auto gap-2">
          {categories.map((cat) => (
            <TabsTrigger
              key={cat}
              value={cat}
              onClick={() => setSearchParams(cat === 'all' ? {} : { category: cat })}
              className="capitalize"
            >
              {cat === 'all' ? 'All' : t(cat)}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {/* Vehicle Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredCars.map((car) => (
          <Card key={car.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="aspect-video overflow-hidden bg-gray-100">
              <img
                src={car.image}
                alt={car.name}
                className="w-full h-full object-cover"
              />
            </div>
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="text-xl mb-1">{car.name}</h3>
                  <p className="text-sm text-gray-600">{car.brand} • {car.year}</p>
                </div>
                <Badge variant={car.available ? 'default' : 'secondary'}>
                  {car.available ? (
                    <CheckCircle className="w-3 h-3 mr-1" />
                  ) : (
                    <XCircle className="w-3 h-3 mr-1" />
                  )}
                  {car.available ? t('available') : t('notAvailable')}
                </Badge>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Users className="w-4 h-4" />
                  <span>{car.seats} {t('seats')}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Settings className="w-4 h-4" />
                  <span>{car.transmission}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Fuel className="w-4 h-4" />
                  <span>{car.fuelType}</span>
                </div>
              </div>

              <div className="flex items-end justify-between">
                <div>
                  <span className="text-2xl">${car.price}</span>
                  <span className="text-sm text-gray-600">/{t('perDay')}</span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="p-4 pt-0">
              <Button
                className="w-full"
                onClick={() => navigate(`/vehicles/${car.id}`)}
                disabled={!car.available}
              >
                View Details
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {filteredCars.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No vehicles found in this category.</p>
        </div>
      )}
    </div>
  );
}
