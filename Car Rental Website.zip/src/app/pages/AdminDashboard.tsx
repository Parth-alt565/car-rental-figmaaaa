import { useNavigate } from 'react-router';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { cars } from '../data/cars';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Car, CheckCircle, XCircle, FileText, Calendar, MapPin, Eye } from 'lucide-react';
import VehicleMap from '../components/VehicleMap';
import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '../components/ui/dialog';

interface Document {
  id: number;
  user: string;
  type: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  date: string;
  documents?: {
    drivingLicense?: string;
    aadharCard?: string;
    panCard?: string;
    passport?: string;
    visa?: string;
    utility?: string;
  };
}

export default function AdminDashboard() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [documents, setDocuments] = useState<Document[]>([
    { 
      id: 1, 
      user: 'John Doe', 
      type: 'Indian', 
      status: 'Pending', 
      date: '2024-03-10',
      documents: {
        drivingLicense: 'https://example.com/dl1.pdf',
        aadharCard: 'https://example.com/aadhar1.pdf',
        panCard: 'https://example.com/pan1.pdf'
      }
    },
    { 
      id: 2, 
      user: 'Jane Smith', 
      type: 'NRI', 
      status: 'Approved', 
      date: '2024-03-09',
      documents: {
        passport: 'https://example.com/passport2.pdf',
        visa: 'https://example.com/visa2.pdf',
        drivingLicense: 'https://example.com/dl2.pdf',
        utility: 'https://example.com/utility2.pdf'
      }
    },
    { 
      id: 3, 
      user: 'Mike Johnson', 
      type: 'Indian', 
      status: 'Pending', 
      date: '2024-03-11',
      documents: {
        drivingLicense: 'https://example.com/dl3.pdf',
        aadharCard: 'https://example.com/aadhar3.pdf',
        panCard: 'https://example.com/pan3.pdf'
      }
    },
    { 
      id: 4, 
      user: 'Sarah Williams', 
      type: 'NRI', 
      status: 'Rejected', 
      date: '2024-03-08',
      documents: {
        passport: 'https://example.com/passport4.pdf',
        visa: 'https://example.com/visa4.pdf',
        drivingLicense: 'https://example.com/dl4.pdf',
        utility: 'https://example.com/utility4.pdf'
      }
    },
    { 
      id: 5, 
      user: 'Tom Brown', 
      type: 'Indian', 
      status: 'Pending', 
      date: '2024-03-11',
      documents: {
        drivingLicense: 'https://example.com/dl5.pdf',
        aadharCard: 'https://example.com/aadhar5.pdf',
        panCard: 'https://example.com/pan5.pdf'
      }
    },
  ]);

  // Use useEffect for navigation instead of calling navigate during render
  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/login/admin');
    }
  }, [user, navigate]);

  const handleApprove = (docId: number) => {
    setDocuments(prevDocs => 
      prevDocs.map(doc => 
        doc.id === docId ? { ...doc, status: 'Approved' as const } : doc
      )
    );
    toast.success(`Document for ${documents.find(d => d.id === docId)?.user} has been approved`);
  };

  const handleReject = (docId: number) => {
    setDocuments(prevDocs => 
      prevDocs.map(doc => 
        doc.id === docId ? { ...doc, status: 'Rejected' as const } : doc
      )
    );
    toast.error(`Document for ${documents.find(d => d.id === docId)?.user} has been rejected`);
  };

  // Don't render anything if not authorized
  if (!user || user.role !== 'admin') {
    return null;
  }

  const totalVehicles = cars.length;
  const availableVehicles = cars.filter((car) => car.available).length;
  const totalBookings = 47; // Mock data
  const pendingDocs = 12; // Mock data

  const categoryCounts = {
    suv: cars.filter((c) => c.category === 'suv').length,
    offroad: cars.filter((c) => c.category === 'offroad').length,
    sedan: cars.filter((c) => c.category === 'sedan').length,
    sports: cars.filter((c) => c.category === 'sports').length,
    hatchback: cars.filter((c) => c.category === 'hatchback').length,
    ev: cars.filter((c) => c.category === 'ev').length,
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl mb-8">{t('adminDashboard')}</h1>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">{t('totalVehicles')}</p>
                <p className="text-3xl">{totalVehicles}</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                <Car className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">{t('availableVehicles')}</p>
                <p className="text-3xl">{availableVehicles}</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">{t('totalBookings')}</p>
                <p className="text-3xl">{totalBookings}</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                <Calendar className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">{t('pendingDocuments')}</p>
                <p className="text-3xl">{pendingDocs}</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center">
                <FileText className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="vehicles" className="space-y-6">
        <TabsList>
          <TabsTrigger value="vehicles">{t('vehicleManagement')}</TabsTrigger>
          <TabsTrigger value="tracking">
            <MapPin className="w-4 h-4 mr-2" />
            Vehicle Tracking
          </TabsTrigger>
          <TabsTrigger value="documents">{t('documentVerification')}</TabsTrigger>
        </TabsList>

        {/* Vehicles Tab */}
        <TabsContent value="vehicles">
          <Card>
            <CardHeader>
              <CardTitle>Vehicle Inventory by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                {Object.entries(categoryCounts).map(([category, count]) => (
                  <div
                    key={category}
                    className="p-4 bg-gray-50 rounded-lg border border-gray-200"
                  >
                    <p className="text-sm text-gray-600 mb-1 capitalize">
                      {t(category)}
                    </p>
                    <p className="text-2xl">{count} vehicles</p>
                  </div>
                ))}
              </div>

              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Vehicle</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Price/Day</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cars.slice(0, 10).map((car) => (
                      <TableRow key={car.id}>
                        <TableCell>
                          <div>
                            <p>{car.name}</p>
                            <p className="text-sm text-gray-600">{car.brand}</p>
                          </div>
                        </TableCell>
                        <TableCell className="capitalize">{t(car.category)}</TableCell>
                        <TableCell>${car.price}</TableCell>
                        <TableCell>
                          <Badge variant={car.available ? 'default' : 'secondary'}>
                            {car.available ? (
                              <>
                                <CheckCircle className="w-3 h-3 mr-1" />
                                {t('available')}
                              </>
                            ) : (
                              <>
                                <XCircle className="w-3 h-3 mr-1" />
                                {t('notAvailable')}
                              </>
                            )}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => navigate(`/vehicles/${car.id}`)}
                          >
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tracking Tab */}
        <TabsContent value="tracking">
          <VehicleMap />
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents">
          <Card>
            <CardHeader>
              <CardTitle>Document Verification Queue</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Customer Type</TableHead>
                      <TableHead>Submission Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {documents.map((doc) => (
                      <TableRow key={doc.id}>
                        <TableCell>{doc.user}</TableCell>
                        <TableCell>{doc.type}</TableCell>
                        <TableCell>{doc.date}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              doc.status === 'Approved'
                                ? 'default'
                                : doc.status === 'Rejected'
                                ? 'destructive'
                                : 'secondary'
                            }
                          >
                            {doc.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedDocument(doc)}
                            >
                              Review
                            </Button>
                            {doc.status === 'Pending' && (
                              <>
                                <Button variant="default" size="sm" onClick={() => handleApprove(doc.id)}>
                                  Approve
                                </Button>
                                <Button variant="destructive" size="sm" onClick={() => handleReject(doc.id)}>
                                  Reject
                                </Button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Document Review Dialog */}
      <Dialog open={selectedDocument !== null} onOpenChange={(open) => !open && setSelectedDocument(null)}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="text-xl">Document Review</DialogTitle>
            <DialogDescription>
              Review the documents submitted by {selectedDocument?.user}
            </DialogDescription>
          </DialogHeader>
          
          {selectedDocument && (
            <div className="space-y-6">
              {/* User Info */}
              <div className="bg-gray-900/50 border border-red-500/20 rounded-lg p-4">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-gray-400">Name:</span>
                    <p className="font-semibold">{selectedDocument.user}</p>
                  </div>
                  <div>
                    <span className="text-gray-400">Type:</span>
                    <p className="font-semibold">{selectedDocument.type}</p>
                  </div>
                  <div>
                    <span className="text-gray-400">Date:</span>
                    <p className="font-semibold">{selectedDocument.date}</p>
                  </div>
                  <div>
                    <span className="text-gray-400">Status:</span>
                    <Badge
                      variant={
                        selectedDocument.status === 'Approved'
                          ? 'default'
                          : selectedDocument.status === 'Rejected'
                          ? 'destructive'
                          : 'secondary'
                      }
                    >
                      {selectedDocument.status}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Documents List */}
              <div className="space-y-2">
                <h3 className="font-semibold mb-3">Submitted Documents</h3>
                {selectedDocument.documents?.drivingLicense && (
                  <div className="flex items-center justify-between p-3 bg-gray-900/30 border border-gray-800 rounded-lg hover:border-red-500/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-red-500" />
                      <span className="text-sm">Driving License</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(selectedDocument.documents?.drivingLicense, '_blank')}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View
                    </Button>
                  </div>
                )}
                {selectedDocument.documents?.aadharCard && (
                  <div className="flex items-center justify-between p-3 bg-gray-900/30 border border-gray-800 rounded-lg hover:border-red-500/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-red-500" />
                      <span className="text-sm">Aadhar Card</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(selectedDocument.documents?.aadharCard, '_blank')}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View
                    </Button>
                  </div>
                )}
                {selectedDocument.documents?.panCard && (
                  <div className="flex items-center justify-between p-3 bg-gray-900/30 border border-gray-800 rounded-lg hover:border-red-500/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-red-500" />
                      <span className="text-sm">PAN Card</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(selectedDocument.documents?.panCard, '_blank')}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View
                    </Button>
                  </div>
                )}
                {selectedDocument.documents?.passport && (
                  <div className="flex items-center justify-between p-3 bg-gray-900/30 border border-gray-800 rounded-lg hover:border-red-500/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-red-500" />
                      <span className="text-sm">Passport</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(selectedDocument.documents?.passport, '_blank')}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View
                    </Button>
                  </div>
                )}
                {selectedDocument.documents?.visa && (
                  <div className="flex items-center justify-between p-3 bg-gray-900/30 border border-gray-800 rounded-lg hover:border-red-500/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-red-500" />
                      <span className="text-sm">Visa</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(selectedDocument.documents?.visa, '_blank')}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View
                    </Button>
                  </div>
                )}
                {selectedDocument.documents?.utility && (
                  <div className="flex items-center justify-between p-3 bg-gray-900/30 border border-gray-800 rounded-lg hover:border-red-500/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-red-500" />
                      <span className="text-sm">Utility Bill</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(selectedDocument.documents?.utility, '_blank')}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View
                    </Button>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              {selectedDocument.status === 'Pending' && (
                <div className="flex gap-3 pt-4 border-t border-gray-800">
                  <Button
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    onClick={() => {
                      handleApprove(selectedDocument.id);
                      setSelectedDocument(null);
                    }}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Approve Documents
                  </Button>
                  <Button
                    variant="destructive"
                    className="flex-1"
                    onClick={() => {
                      handleReject(selectedDocument.id);
                      setSelectedDocument(null);
                    }}
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Reject Documents
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}