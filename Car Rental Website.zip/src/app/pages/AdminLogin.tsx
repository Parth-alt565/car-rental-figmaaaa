import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Shield } from 'lucide-react';
import { toast } from 'sonner';

export default function AdminLogin() {
  const { t } = useLanguage();
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(email, password, 'admin');
    if (success) {
      toast.success('Admin login successful!');
      navigate('/admin');
    } else {
      toast.error('Invalid admin credentials. Use: admin@carental.com / admin123');
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 flex items-center justify-center min-h-[calc(100vh-200px)]">
      <Card className="w-full max-w-md border-blue-200">
        <CardHeader>
          <div className="flex items-center gap-2 mb-2">
            <Shield className="w-6 h-6 text-blue-600" />
            <CardTitle className="text-2xl">{t('adminLogin')}</CardTitle>
          </div>
          <CardDescription>
            Administrator access only - Enter your admin credentials
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="admin-email">{t('email')}</Label>
              <Input
                id="admin-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@carental.com"
                required
              />
            </div>
            <div>
              <Label htmlFor="admin-password">{t('password')}</Label>
              <Input
                id="admin-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>
            <Button type="submit" className="w-full">
              {t('signIn')}
            </Button>
          </form>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800 mb-2">Demo admin credentials:</p>
            <p className="text-xs text-blue-600">Email: admin@carental.com</p>
            <p className="text-xs text-blue-600">Password: admin123</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
