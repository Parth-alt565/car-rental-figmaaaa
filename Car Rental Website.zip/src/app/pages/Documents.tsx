import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Label } from '../components/ui/label';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { Upload, FileText, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

type CustomerType = 'indian' | 'nri';

interface DocumentFile {
  name: string;
  file: File | null;
  uploaded: boolean;
}

export default function Documents() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [customerType, setCustomerType] = useState<CustomerType>('indian');
  const [documents, setDocuments] = useState<{ [key: string]: DocumentFile }>({
    drivingLicense: { name: 'Driving License', file: null, uploaded: false },
    aadharCard: { name: 'Aadhar Card', file: null, uploaded: false },
    addressProof: { name: 'Address Proof', file: null, uploaded: false },
  });

  const [nriDocuments, setNriDocuments] = useState<{ [key: string]: DocumentFile }>({
    drivingLicense: { name: 'Driving License', file: null, uploaded: false },
    passport: { name: 'Passport', file: null, uploaded: false },
    visaDocument: { name: 'Visa Document', file: null, uploaded: false },
    addressProof: { name: 'Address Proof', file: null, uploaded: false },
  });

  if (!user) {
    navigate('/login/user');
    return null;
  }

  const currentDocs = customerType === 'indian' ? documents : nriDocuments;
  const setCurrentDocs = customerType === 'indian' ? setDocuments : setNriDocuments;

  const handleFileChange = (docKey: string, file: File | null) => {
    if (file) {
      setCurrentDocs((prev) => ({
        ...prev,
        [docKey]: { ...prev[docKey], file, uploaded: false },
      }));
    }
  };

  const handleUpload = (docKey: string) => {
    const doc = currentDocs[docKey];
    if (doc.file) {
      // Simulate upload
      setTimeout(() => {
        setCurrentDocs((prev) => ({
          ...prev,
          [docKey]: { ...prev[docKey], uploaded: true },
        }));
        toast.success(`${doc.name} uploaded successfully!`);
      }, 1000);
    } else {
      toast.error('Please select a file first');
    }
  };

  const allDocumentsUploaded = Object.values(currentDocs).every((doc) => doc.uploaded);

  const handleSubmit = () => {
    if (allDocumentsUploaded) {
      toast.success('All documents submitted successfully! Our team will verify them shortly.');
    } else {
      toast.error('Please upload all required documents');
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <h1 className="text-4xl mb-8">{t('uploadDocuments')}</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>{t('customerType')}</CardTitle>
        </CardHeader>
        <CardContent>
          <RadioGroup
            value={customerType}
            onValueChange={(value) => setCustomerType(value as CustomerType)}
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="indian" id="indian" />
              <Label htmlFor="indian" className="cursor-pointer">
                {t('indian')}
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="nri" id="nri" />
              <Label htmlFor="nri" className="cursor-pointer">
                {t('nri')}
              </Label>
            </div>
          </RadioGroup>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {Object.entries(currentDocs).map(([key, doc]) => (
          <Card key={key}>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className="w-5 h-5 text-gray-600" />
                    <h3 className="text-lg">
                      {t(key) !== key ? t(key) : doc.name}
                    </h3>
                    {doc.uploaded && (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    )}
                  </div>
                  {doc.file && (
                    <p className="text-sm text-gray-600 truncate">{doc.file.name}</p>
                  )}
                </div>

                <div className="flex gap-2">
                  <div className="relative">
                    <input
                      type="file"
                      id={`file-${key}`}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      onChange={(e) =>
                        handleFileChange(key, e.target.files?.[0] || null)
                      }
                      accept=".pdf,.jpg,.jpeg,.png"
                      disabled={doc.uploaded}
                    />
                    <Button
                      variant="outline"
                      disabled={doc.uploaded}
                      className="pointer-events-none"
                    >
                      {t('selectFile')}
                    </Button>
                  </div>

                  <Button
                    onClick={() => handleUpload(key)}
                    disabled={!doc.file || doc.uploaded}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    {doc.uploaded ? 'Uploaded' : t('upload')}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-8">
        <Button
          size="lg"
          className="w-full"
          onClick={handleSubmit}
          disabled={!allDocumentsUploaded}
        >
          Submit All Documents
        </Button>
        {!allDocumentsUploaded && (
          <p className="text-sm text-gray-600 text-center mt-2">
            Please upload all required documents before submitting
          </p>
        )}
      </div>

      <Card className="mt-6 bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <p className="text-sm text-blue-800">
            <strong>Note:</strong> All documents should be clear, valid, and in PDF, JPG, or PNG
            format. Maximum file size: 5MB per document.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
