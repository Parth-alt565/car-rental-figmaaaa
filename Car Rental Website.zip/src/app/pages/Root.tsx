import { Outlet, Link, useNavigate } from 'react-router';
import { useLanguage, languages } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { Car, LogOut, Globe, Menu, X } from 'lucide-react';
import { Button } from '../components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../components/ui/dropdown-menu';
import { useState } from 'react';

export default function Root() {
  const { language, setLanguage, t } = useLanguage();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-white/10 bg-black/80 backdrop-blur-xl sticky top-0 z-50 shadow-[0_4px_30px_rgba(0,0,0,0.3)]">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-20">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="relative">
                <div className="absolute inset-0 bg-red-600 rounded-lg blur-lg opacity-50 group-hover:opacity-75 transition-opacity"></div>
                <Car className="w-10 h-10 text-red-600 relative z-10" />
              </div>
              <span className="text-2xl font-bold tracking-wider">
                CAR<span className="text-gradient">RENTAL</span>
              </span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              <Link
                to="/"
                className="relative group py-2 font-medium transition-colors hover:text-red-500"
              >
                {t('home')}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-red-600 to-red-500 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                to="/vehicles"
                className="relative group py-2 font-medium transition-colors hover:text-red-500"
              >
                {t('vehicles')}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-red-600 to-red-500 group-hover:w-full transition-all duration-300"></span>
              </Link>
              {user && (
                <Link
                  to="/documents"
                  className="relative group py-2 font-medium transition-colors hover:text-red-500"
                >
                  {t('documents')}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-red-600 to-red-500 group-hover:w-full transition-all duration-300"></span>
                </Link>
              )}
              {user?.role === 'admin' && (
                <Link
                  to="/admin"
                  className="relative group py-2 font-medium transition-colors hover:text-red-500"
                >
                  {t('adminDashboard')}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-red-600 to-red-500 group-hover:w-full transition-all duration-300"></span>
                </Link>
              )}
            </nav>

            <div className="hidden md:flex items-center gap-4">
              {/* Language Selector */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="backdrop-blur-sm">
                    <Globe className="w-4 h-4 mr-2" />
                    {languages.find((l) => l.code === language)?.flag}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  align="end"
                  className="max-h-96 overflow-y-auto backdrop-blur-xl bg-black/90 border-white/10"
                >
                  {languages.map((lang) => (
                    <DropdownMenuItem
                      key={lang.code}
                      onClick={() => setLanguage(lang.code)}
                      className="cursor-pointer hover:bg-red-500/10 hover:text-red-500"
                    >
                      <span className="mr-2">{lang.flag}</span>
                      {lang.name}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Auth Buttons */}
              {user ? (
                <div className="flex items-center gap-3">
                  <div className="px-4 py-2 rounded-lg bg-gradient-to-r from-red-600/10 to-red-500/5 border border-red-500/20">
                    <span className="text-sm font-medium">{user.name}</span>
                  </div>
                  <Button variant="outline" size="sm" onClick={handleLogout}>
                    <LogOut className="w-4 h-4 mr-2" />
                    {t('logout')}
                  </Button>
                </div>
              ) : (
                <div className="flex gap-3">
                  <Button variant="outline" size="sm" onClick={() => navigate('/login/user')}>
                    {t('userLogin')}
                  </Button>
                  <Button variant="default" size="sm" onClick={() => navigate('/login/admin')}>
                    {t('adminLogin')}
                  </Button>
                </div>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-red-500/10 transition-colors"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t border-white/10">
              <nav className="flex flex-col gap-2">
                <Link
                  to="/"
                  className="px-4 py-3 hover:bg-red-500/10 rounded-lg transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {t('home')}
                </Link>
                <Link
                  to="/vehicles"
                  className="px-4 py-3 hover:bg-red-500/10 rounded-lg transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {t('vehicles')}
                </Link>
                {user && (
                  <Link
                    to="/documents"
                    className="px-4 py-3 hover:bg-red-500/10 rounded-lg transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {t('documents')}
                  </Link>
                )}
                {user?.role === 'admin' && (
                  <Link
                    to="/admin"
                    className="px-4 py-3 hover:bg-red-500/10 rounded-lg transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {t('adminDashboard')}
                  </Link>
                )}
                <div className="px-4 py-2 border-t border-white/10 mt-2 pt-4">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm" className="w-full">
                        <Globe className="w-4 h-4 mr-2" />
                        {languages.find((l) => l.code === language)?.name}
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="max-h-96 overflow-y-auto">
                      {languages.map((lang) => (
                        <DropdownMenuItem
                          key={lang.code}
                          onClick={() => setLanguage(lang.code)}
                          className="cursor-pointer"
                        >
                          <span className="mr-2">{lang.flag}</span>
                          {lang.name}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                {user ? (
                  <div className="px-4 py-2 border-t border-white/10 mt-2 pt-4 flex flex-col gap-2">
                    <div className="px-4 py-2 rounded-lg bg-red-500/10 border border-red-500/20">
                      <span className="text-sm">{user.name}</span>
                    </div>
                    <Button variant="outline" size="sm" onClick={handleLogout}>
                      <LogOut className="w-4 h-4 mr-2" />
                      {t('logout')}
                    </Button>
                  </div>
                ) : (
                  <div className="px-4 py-2 border-t border-white/10 mt-2 pt-4 flex flex-col gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        navigate('/login/user');
                        setMobileMenuOpen(false);
                      }}
                    >
                      {t('userLogin')}
                    </Button>
                    <Button
                      variant="default"
                      size="sm"
                      onClick={() => {
                        navigate('/login/admin');
                        setMobileMenuOpen(false);
                      }}
                    >
                      {t('adminLogin')}
                    </Button>
                  </div>
                )}
              </nav>
            </div>
          )}
        </div>
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="relative border-t border-white/10 py-12 bg-black/50 backdrop-blur-sm">
        <div className="absolute inset-0 bg-gradient-to-t from-red-950/20 to-transparent"></div>
        <div className="container mx-auto px-4 relative">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-3">
              <Car className="w-8 h-8 text-red-600" />
              <span className="text-xl font-bold">
                CAR<span className="text-gradient">RENTAL</span>
              </span>
            </div>
            <p className="text-sm text-gray-400">
              © 2026 CarRental. Premium luxury vehicles at your service.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}