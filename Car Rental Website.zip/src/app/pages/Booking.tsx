import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { getCarById } from '../data/cars';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Checkbox } from '../components/ui/checkbox';
import { Calendar } from '../components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '../components/ui/popover';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  CreditCard, 
  Shield, 
  AlertTriangle,
  CheckCircle,
  ArrowLeft
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

type BookingStep = 'dates' | 'agreement' | 'payment' | 'confirmation';

export default function Booking() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { t } = useLanguage();

  const car = id ? getCarById(id) : null;

  const [step, setStep] = useState<BookingStep>('dates');
  const [pickupDate, setPickupDate] = useState<Date>();
  const [returnDate, setReturnDate] = useState<Date>();
  const [pickupTime, setPickupTime] = useState('10:00');
  const [returnTime, setReturnTime] = useState('10:00');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [depositPaid, setDepositPaid] = useState(false);
  
  // Payment details
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');

  // Use useEffect for navigation instead of calling navigate during render
  useEffect(() => {
    if (!user) {
      navigate('/login/user');
    }
  }, [user, navigate]);

  // Don't render anything if not authorized
  if (!user) {
    return null;
  }

  if (!car) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl mb-4">Vehicle not found</h2>
        <Button onClick={() => navigate('/vehicles')}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Vehicles
        </Button>
      </div>
    );
  }

  const calculateDays = () => {
    if (!pickupDate || !returnDate) return 0;
    const diff = returnDate.getTime() - pickupDate.getTime();
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  };

  const days = calculateDays();
  const rentalCost = days * car.price;
  const depositAmount = car.price * 2; // 2 days worth as deposit
  const totalCost = rentalCost + depositAmount;

  const handleDatesContinue = () => {
    if (!pickupDate || !returnDate) {
      toast.error('Please select both pickup and return dates');
      return;
    }
    if (returnDate <= pickupDate) {
      toast.error('Return date must be after pickup date');
      return;
    }
    setStep('agreement');
  };

  const handleAgreementContinue = () => {
    if (!agreedToTerms) {
      toast.error('You must agree to the terms and conditions');
      return;
    }
    setStep('payment');
  };

  const handlePayment = () => {
    if (!cardNumber || !cardName || !expiryDate || !cvv) {
      toast.error('Please fill in all payment details');
      return;
    }
    
    // Simulate payment processing
    setTimeout(() => {
      setDepositPaid(true);
      setStep('confirmation');
      toast.success('Payment successful! Booking confirmed.');
    }, 1500);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Button 
        variant="ghost" 
        onClick={() => navigate(`/vehicles/${car.id}`)} 
        className="mb-6"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Vehicle
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Booking Area */}
        <div className="lg:col-span-2 space-y-6">
          {/* Progress Steps */}
          <div className="flex items-center justify-between mb-8">
            {['dates', 'agreement', 'payment', 'confirmation'].map((s, idx) => (
              <div key={s} className="flex items-center flex-1">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                    step === s
                      ? 'border-red-500 bg-red-500 text-white'
                      : idx < ['dates', 'agreement', 'payment', 'confirmation'].indexOf(step)
                      ? 'border-red-500 bg-red-500 text-white'
                      : 'border-gray-600 bg-gray-800 text-gray-400'
                  }`}
                >
                  {idx + 1}
                </div>
                {idx < 3 && (
                  <div
                    className={`flex-1 h-0.5 mx-2 ${
                      idx < ['dates', 'agreement', 'payment', 'confirmation'].indexOf(step)
                        ? 'bg-red-500'
                        : 'bg-gray-700'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>

          {/* Step 1: Date & Time Selection */}
          {step === 'dates' && (
            <Card className="border-red-500/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <CalendarIcon className="w-6 h-6 text-red-500" />
                  Select Pickup & Return
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Pickup Date & Time */}
                  <div className="space-y-4">
                    <Label className="text-lg">Pickup Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {pickupDate ? format(pickupDate, 'PPP') : 'Select date'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={pickupDate}
                          onSelect={setPickupDate}
                          disabled={(date) => date < new Date()}
                        />
                      </PopoverContent>
                    </Popover>

                    <div>
                      <Label>Pickup Time</Label>
                      <div className="flex items-center gap-2 mt-2">
                        <Clock className="w-4 h-4 text-red-500" />
                        <Input
                          type="time"
                          value={pickupTime}
                          onChange={(e) => setPickupTime(e.target.value)}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Return Date & Time */}
                  <div className="space-y-4">
                    <Label className="text-lg">Return Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {returnDate ? format(returnDate, 'PPP') : 'Select date'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={returnDate}
                          onSelect={setReturnDate}
                          disabled={(date) => date < (pickupDate || new Date())}
                        />
                      </PopoverContent>
                    </Popover>

                    <div>
                      <Label>Return Time</Label>
                      <div className="flex items-center gap-2 mt-2">
                        <Clock className="w-4 h-4 text-red-500" />
                        <Input
                          type="time"
                          value={returnTime}
                          onChange={(e) => setReturnTime(e.target.value)}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <Button 
                  className="w-full bg-red-600 hover:bg-red-700" 
                  size="lg"
                  onClick={handleDatesContinue}
                >
                  Continue to Agreement
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Step 2: User Agreement */}
          {step === 'agreement' && (
            <Card className="border-red-500/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Shield className="w-6 h-6 text-red-500" />
                  Rental Agreement & Terms
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-gray-900/50 border border-red-500/20 rounded-lg p-6 max-h-96 overflow-y-auto space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold mb-2 text-red-500">Vehicle Damage Policy</h3>
                    <p className="text-sm text-gray-300">
                      The renter is fully responsible for any damage to the vehicle during the rental period. 
                      This includes but is not limited to:
                    </p>
                    <ul className="list-disc list-inside text-sm text-gray-300 mt-2 space-y-1">
                      <li>Bodywork damage, scratches, or dents</li>
                      <li>Interior damage or excessive wear</li>
                      <li>Windscreen or window damage</li>
                      <li>Tire or wheel damage</li>
                      <li>Mechanical damage due to misuse</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-2 text-red-500">Violation Penalties</h3>
                    <p className="text-sm text-gray-300">
                      The following violations will result in immediate fines and may affect your deposit:
                    </p>
                    <ul className="list-disc list-inside text-sm text-gray-300 mt-2 space-y-1">
                      <li>Late return: $50 per hour + daily rate after 24 hours</li>
                      <li>Smoking in vehicle: $250 cleaning fee</li>
                      <li>Unauthorized driver: $500 fine + insurance void</li>
                      <li>Off-road use (non off-road vehicles): $1000 fine + damages</li>
                      <li>Speeding tickets: Full fine amount + $100 processing fee</li>
                      <li>DUI/DWI: Full deposit forfeiture + legal action</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-2 text-red-500">Security Deposit</h3>
                    <p className="text-sm text-gray-300">
                      A refundable security deposit of ${depositAmount} is required. This will be held for 
                      7-14 business days after vehicle return for damage inspection and traffic violation 
                      checks. The deposit will be refunded in full if no violations or damage are found.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-2 text-red-500">Insurance Coverage</h3>
                    <p className="text-sm text-gray-300">
                      Basic insurance is included. However, you are responsible for the first $1000 of any 
                      claim (excess/deductible). Additional coverage can reduce this to $250.
                    </p>
                  </div>

                  <div className="bg-red-900/20 border border-red-500/30 rounded p-4">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-semibold text-red-500">Important Notice</p>
                        <p className="text-xs text-gray-300 mt-1">
                          By agreeing to these terms, you acknowledge full financial responsibility for 
                          the vehicle and any violations incurred during your rental period.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-start space-x-3 p-4 bg-gray-900/50 border border-red-500/20 rounded-lg">
                  <Checkbox
                    id="terms"
                    checked={agreedToTerms}
                    onCheckedChange={(checked) => setAgreedToTerms(checked as boolean)}
                  />
                  <label
                    htmlFor="terms"
                    className="text-sm leading-relaxed cursor-pointer"
                  >
                    I have read, understood, and agree to all terms and conditions. I accept full 
                    responsibility for the vehicle and will pay all fines, damages, and fees as outlined above.
                  </label>
                </div>

                <div className="flex gap-4">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => setStep('dates')}
                  >
                    Back
                  </Button>
                  <Button 
                    className="flex-1 bg-red-600 hover:bg-red-700" 
                    size="lg"
                    onClick={handleAgreementContinue}
                  >
                    Continue to Payment
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: Payment */}
          {step === 'payment' && (
            <Card className="border-red-500/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <CreditCard className="w-6 h-6 text-red-500" />
                  Payment Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4 mb-6">
                  <p className="text-sm">
                    <span className="font-semibold">Demo Payment:</span> Use card number 4242 4242 4242 4242 
                    for testing. Any future date and 3-digit CVV will work.
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label>Card Number</Label>
                    <Input
                      placeholder="4242 4242 4242 4242"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      maxLength={19}
                    />
                  </div>

                  <div>
                    <Label>Cardholder Name</Label>
                    <Input
                      placeholder="John Doe"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Expiry Date</Label>
                      <Input
                        placeholder="MM/YY"
                        value={expiryDate}
                        onChange={(e) => setExpiryDate(e.target.value)}
                        maxLength={5}
                      />
                    </div>
                    <div>
                      <Label>CVV</Label>
                      <Input
                        placeholder="123"
                        type="password"
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value)}
                        maxLength={3}
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-gray-900/50 border border-red-500/20 rounded-lg p-6 space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Rental Cost ({days} days)</span>
                    <span>${rentalCost.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Security Deposit (Refundable)</span>
                    <span className="text-red-500">${depositAmount.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-gray-700 pt-3 flex justify-between text-lg font-semibold">
                    <span>Total Charge</span>
                    <span className="text-red-500">${totalCost.toFixed(2)}</span>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => setStep('agreement')}
                  >
                    Back
                  </Button>
                  <Button 
                    className="flex-1 bg-red-600 hover:bg-red-700" 
                    size="lg"
                    onClick={handlePayment}
                  >
                    Pay ${totalCost.toFixed(2)}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 4: Confirmation */}
          {step === 'confirmation' && (
            <Card className="border-green-500/20">
              <CardContent className="p-12 text-center">
                <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="w-12 h-12 text-green-500" />
                </div>
                <h2 className="text-3xl mb-4">Booking Confirmed!</h2>
                <p className="text-gray-400 mb-8">
                  Your reservation has been confirmed. Check your email for booking details.
                </p>
                <div className="space-y-2 text-left max-w-md mx-auto mb-8">
                  <div className="flex justify-between py-2 border-b border-gray-800">
                    <span className="text-gray-400">Booking ID:</span>
                    <span className="font-semibold">#{Math.random().toString(36).substr(2, 9).toUpperCase()}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-gray-800">
                    <span className="text-gray-400">Vehicle:</span>
                    <span className="font-semibold">{car.name}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-gray-800">
                    <span className="text-gray-400">Pickup:</span>
                    <span className="font-semibold">
                      {pickupDate && format(pickupDate, 'PPP')} at {pickupTime}
                    </span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-gray-800">
                    <span className="text-gray-400">Return:</span>
                    <span className="font-semibold">
                      {returnDate && format(returnDate, 'PPP')} at {returnTime}
                    </span>
                  </div>
                </div>
                <div className="flex gap-4 justify-center">
                  <Button variant="outline" onClick={() => navigate('/')}>
                    Back to Home
                  </Button>
                  <Button 
                    className="bg-red-600 hover:bg-red-700"
                    onClick={() => navigate('/documents')}
                  >
                    Upload Documents
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Summary Sidebar */}
        <div className="lg:col-span-1">
          <Card className="sticky top-24 border-red-500/20">
            <CardHeader>
              <CardTitle>Booking Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="aspect-video rounded-lg overflow-hidden">
                <img src={car.image} alt={car.name} className="w-full h-full object-cover" />
              </div>
              
              <div>
                <h3 className="text-xl font-semibold">{car.name}</h3>
                <p className="text-sm text-gray-400">{car.brand} • {car.year}</p>
              </div>

              <div className="space-y-2 pt-4 border-t border-gray-800">
                {pickupDate && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Pickup:</span>
                    <span>{format(pickupDate, 'MMM dd')}</span>
                  </div>
                )}
                {returnDate && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Return:</span>
                    <span>{format(returnDate, 'MMM dd')}</span>
                  </div>
                )}
                {days > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Duration:</span>
                    <span>{days} days</span>
                  </div>
                )}
              </div>

              {days > 0 && (
                <div className="space-y-2 pt-4 border-t border-gray-800">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Daily Rate:</span>
                    <span>${car.price}/day</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Rental Total:</span>
                    <span>${rentalCost}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Deposit:</span>
                    <span className="text-red-500">${depositAmount}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-gray-800">
                    <span className="font-semibold">Total:</span>
                    <span className="font-semibold text-red-500 text-lg">${totalCost}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}