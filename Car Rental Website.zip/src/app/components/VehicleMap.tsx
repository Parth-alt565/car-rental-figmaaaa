import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { MapPin, Navigation } from 'lucide-react';

interface VehicleLocation {
  id: string;
  name: string;
  lat: number;
  lng: number;
  status: 'active' | 'idle' | 'maintenance';
  speed: number;
  lastUpdate: string;
}

// Mock vehicle locations
const mockVehicleLocations: VehicleLocation[] = [
  { id: 'suv-1', name: 'Toyota Fortuner', lat: 28.6139, lng: 77.2090, status: 'active', speed: 45, lastUpdate: '2 mins ago' },
  { id: 'suv-2', name: 'Ford Endeavour', lat: 28.7041, lng: 77.1025, status: 'idle', speed: 0, lastUpdate: '15 mins ago' },
  { id: 'sedan-1', name: 'Honda City', lat: 28.5355, lng: 77.3910, status: 'active', speed: 60, lastUpdate: '1 min ago' },
  { id: 'sports-1', name: 'Porsche 911', lat: 28.4595, lng: 77.0266, status: 'active', speed: 120, lastUpdate: 'Just now' },
  { id: 'ev-1', name: 'Tesla Model 3', lat: 28.6692, lng: 77.4538, status: 'idle', speed: 0, lastUpdate: '5 mins ago' },
];

export default function VehicleMap() {
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleLocation | null>(null);

  return (
    <Card className="border-red-500/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-red-500" />
          Live Vehicle Tracking
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Map Area */}
          <div className="lg:col-span-2">
            <div className="relative w-full h-96 bg-gray-900 rounded-lg overflow-hidden border border-red-500/20">
              {/* Mock Map Background */}
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxkZWZzPjxwYXR0ZXJuIGlkPSJncmlkIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiPjxwYXRoIGQ9Ik0gNDAgMCBMIDAgMCAwIDQwIiBmaWxsPSJub25lIiBzdHJva2U9InJnYmEoMjU1LDI1NSwyNTUsMC4wNSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-50"></div>
              
              {/* Mock Roads */}
              <svg className="absolute inset-0 w-full h-full">
                <line x1="0" y1="200" x2="100%" y2="200" stroke="rgba(255,255,255,0.1)" strokeWidth="3" />
                <line x1="300" y1="0" x2="300" y2="100%" stroke="rgba(255,255,255,0.1)" strokeWidth="3" />
                <line x1="0" y1="100" x2="100%" y2="100" stroke="rgba(255,255,255,0.1)" strokeWidth="2" />
                <line x1="150" y1="0" x2="150" y2="100%" stroke="rgba(255,255,255,0.1)" strokeWidth="2" />
              </svg>

              {/* Vehicle Markers */}
              {mockVehicleLocations.map((vehicle, idx) => {
                const x = 50 + (idx * 100) + (Math.random() * 50);
                const y = 50 + (idx * 60) + (Math.random() * 50);
                
                return (
                  <div
                    key={vehicle.id}
                    className="absolute cursor-pointer group"
                    style={{ 
                      left: `${x % 90}%`, 
                      top: `${y % 80}%`,
                      transform: 'translate(-50%, -50%)'
                    }}
                    onClick={() => setSelectedVehicle(vehicle)}
                  >
                    {/* Pulse Effect */}
                    {vehicle.status === 'active' && (
                      <div className="absolute inset-0 animate-ping">
                        <div className={`w-4 h-4 rounded-full ${
                          vehicle.status === 'active' ? 'bg-green-500' : 
                          vehicle.status === 'idle' ? 'bg-yellow-500' : 
                          'bg-red-500'
                        } opacity-75`}></div>
                      </div>
                    )}
                    
                    {/* Marker */}
                    <div className={`relative w-8 h-8 rounded-full flex items-center justify-center ${
                      vehicle.status === 'active' ? 'bg-green-500 shadow-lg shadow-green-500/50' : 
                      vehicle.status === 'idle' ? 'bg-yellow-500 shadow-lg shadow-yellow-500/50' : 
                      'bg-red-500 shadow-lg shadow-red-500/50'
                    } border-2 border-white group-hover:scale-125 transition-transform`}>
                      <Navigation className="w-4 h-4 text-white" style={{
                        transform: vehicle.status === 'active' ? 'rotate(45deg)' : 'rotate(0deg)'
                      }} />
                    </div>

                    {/* Tooltip */}
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                      <div className="bg-black/90 text-white text-xs px-3 py-2 rounded-lg whitespace-nowrap shadow-xl border border-red-500/30">
                        <p className="font-semibold">{vehicle.name}</p>
                        <p className="text-gray-300">{vehicle.speed} km/h</p>
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Map Controls */}
              <div className="absolute top-4 right-4 flex flex-col gap-2">
                <button className="w-10 h-10 bg-black/80 hover:bg-black rounded-lg border border-red-500/30 flex items-center justify-center text-white">
                  +
                </button>
                <button className="w-10 h-10 bg-black/80 hover:bg-black rounded-lg border border-red-500/30 flex items-center justify-center text-white">
                  -
                </button>
              </div>

              {/* Legend */}
              <div className="absolute bottom-4 left-4 bg-black/80 backdrop-blur-sm rounded-lg p-3 border border-red-500/30">
                <div className="flex gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span>Active</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <span>Idle</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <span>Maintenance</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Vehicle List */}
          <div className="space-y-3">
            <h3 className="font-semibold text-lg mb-4">Tracked Vehicles</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {mockVehicleLocations.map((vehicle) => (
                <div
                  key={vehicle.id}
                  onClick={() => setSelectedVehicle(vehicle)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    selectedVehicle?.id === vehicle.id
                      ? 'border-red-500 bg-red-500/10'
                      : 'border-gray-800 hover:border-red-500/50 bg-gray-900/50'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-semibold text-sm">{vehicle.name}</h4>
                    <div className={`w-2 h-2 rounded-full ${
                      vehicle.status === 'active' ? 'bg-green-500 animate-pulse' : 
                      vehicle.status === 'idle' ? 'bg-yellow-500' : 
                      'bg-red-500'
                    }`}></div>
                  </div>
                  <div className="text-xs text-gray-400 space-y-1">
                    <p className="flex items-center gap-1">
                      <Navigation className="w-3 h-3" />
                      {vehicle.speed} km/h
                    </p>
                    <p>{vehicle.lastUpdate}</p>
                    <p className="text-gray-500 font-mono text-[10px]">
                      {vehicle.lat.toFixed(4)}, {vehicle.lng.toFixed(4)}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {selectedVehicle && (
              <div className="mt-4 p-4 bg-red-500/10 border border-red-500/30 rounded-lg">
                <h4 className="font-semibold mb-2 text-red-500">Selected Vehicle</h4>
                <div className="text-sm space-y-1">
                  <p><span className="text-gray-400">Name:</span> {selectedVehicle.name}</p>
                  <p><span className="text-gray-400">Status:</span> {selectedVehicle.status}</p>
                  <p><span className="text-gray-400">Speed:</span> {selectedVehicle.speed} km/h</p>
                  <p><span className="text-gray-400">Last Update:</span> {selectedVehicle.lastUpdate}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="mt-6 p-4 bg-yellow-900/20 border border-yellow-500/30 rounded-lg">
          <p className="text-sm text-yellow-500">
            <strong>Demo Mode:</strong> This is a simulated GPS tracking map. In production, 
            this would integrate with Google Maps API and real GPS tracking devices installed in vehicles.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
