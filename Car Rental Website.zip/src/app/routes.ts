import { createBrowserRouter } from 'react-router';
import Root from './pages/Root';
import Home from './pages/Home';
import Vehicles from './pages/Vehicles';
import VehicleDetail from './pages/VehicleDetail';
import Booking from './pages/Booking';
import Documents from './pages/Documents';
import UserLogin from './pages/UserLogin';
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import NotFound from './pages/NotFound';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: 'vehicles', Component: Vehicles },
      { path: 'vehicles/:id', Component: VehicleDetail },
      { path: 'booking/:id', Component: Booking },
      { path: 'documents', Component: Documents },
      { path: 'login/user', Component: UserLogin },
      { path: 'login/admin', Component: AdminLogin },
      { path: 'admin', Component: AdminDashboard },
      { path: '*', Component: NotFound },
    ],
  },
]);